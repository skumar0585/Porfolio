import React, { Component } from 'react';
import Banner from './Banner';

class Home extends Component {
	render() {
		return(
				<div>
					<Banner />
				</div>
			);
	}
}

export default Home;
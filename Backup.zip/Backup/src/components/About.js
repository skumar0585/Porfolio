import React, { Component } from 'react';

class About extends Component {
	render() {
		return(
				<div className="abtBg bgWrap">
					<p>About Component</p>
				</div>
			);
	}
}

export default About;
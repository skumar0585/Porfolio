import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact';
import Banner from './components/Banner';

class App extends Component {
  render() {
    return (
      // <div className="App">
          // <div className="container">
          //   <div className="row">
          //       <div className="col-md-12">
          //         <Header />
          //       </div>
          //   </div>
          //   <div className="row">
          //       <div className="col-md-12">
          //         <Home />
          //       </div>
          //   </div>
          // </div>
      // </div>
          <Router>
            <div>
            <Header />
            <div className="container-fluid">
              <div className="row">
                    <Switch>
                    <Route exact path='/' component={Home} />
                    <Route exact path='/About' component={About} />
                    <Route exact path='/Contact' component={Contact} />
                    </Switch>
                    </div>
               </div>
            </div>
          </Router>
    );
  }
}

export default App;
